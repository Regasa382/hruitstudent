<?php
//login
$ln_bookFine='የመጽሀፍ ኪፈያ';
$ln_email='ኢሜይል';
$ln_password='የይለፍ ቃል';
$ln_language='ቋንቋ';
$ln_loginTitle='መግቢያ ፎርም';
$ln_loginInnerTitle='እባክዎ ፎርሙን ይምሉ';
$ln_login='ግባ';
$ln_cancel='አጥፋ';
$ln_requestAppoitement="ጥያቄውን ያቀረቡበት ቀን";
$ln_lostpassword='የይለፍ ቃሌን ረሳው ??';
$ln_loginIncorectTitle='አልተሳካም';
$ln_viewWithdraw="ወጪ ዕቃ መመልከት";
$ln_loginIncorectEmailMessage='ይቅርታ ያስገቡት ኢሜይል አይገኝም：：';
$ln_loginIncorectPasswordMessage='ይቅርታ ያስገቡት የይለፍ ቃል የተሳሳተ ነው：：';
$ln_loginDeactive='ይቅርታ ይህ ኣካውንት ለግዜው ዝግጁ ኣይደለም ንብረት ክፍሉን ያነጋግሩ';
$ln_withdrawAssetPastDate="ያስገቡት የቀጠሮ ቀን ቢያንስ ከዛረ መብለጥ አለበት";
$ln_withdrawAssetEmptyDate="የቀጠሮ ቀን አልተሞላም";
$ln_lostAssetNoAssetQuantityNegative="የዕቃው ብዛት ከ አንድ በላይ መሆን አለበት";
$ln_propertyMangerApproveRequest="ጥያቄዎችን ማጽደቅ";
$ln_createAccountFailPhone="የስገቡት ስልክ ቁጥር አገልግሎት ላይ ነው";
$ln_approve="አጽድቅ";
$ln_reject="አታጽድቅ";
$ln_lostAssetNoAssetMoreQuantity="ይቅርታ ይህን ያህል ዕቃ ወጭ አላደረጉም";
$ln_preparedDate="የተዘጋጀበት ቀን";
$ln_rejectedReportNotification="ውድቅ የሆነ ሪፖርት አልዎት ";
$ln_approvedReportNotification="የጸደቀ ሪፖርት አልዎት ";
$ln_rejectReportSuccess="ሪፖርቱን በትክክል ዉድቅ አድርገዋል";
$ln_approveReportSuccess="ሪፖርቱን በትክክል አጽድቀዋል ";
$ln_assetPayment='የ ዕቃ ክፍያ';
$ln_generalAssetUser="ጠቅላላ ዕቃ ተጠቃሚ";
$ln_report="ሪፖርት";
$ln_problemReport="ችግሮች";
$ln_giveFeedback="ምላሽ ስጥ";
$ln_generalAssetmanager="ጠቅላላ ንብረት ተቆጠጣሪ";
$ln_generalAssetUserRequest="ጠቅላላ የዕቃ ተጠሚ ጥያቄዎች";
$ln_approveReportTop="ሪፖርት ማጽደቅ";
$ln_approveReportPrepareBy="የአዘጋጅ ስም";
$ln_approveReportPrepareType="የሪፖርት አይነት";
$ln_approveReportPrepareDescription="ማብራሪያ";
$ln_approveReportPrepareDate="የተዘጋጀበት ቀን";
$ln_lostAssetPayement='ለጠፋ ዕቃ ክፍያ መፈፀም';
$ln_accountNumber='የ አካዉንት ቁጥር';
$ln_AccountPassword='የ አካውንት ይለፍ ቃል';
$ln_notification='ማሳወቂያ';
//asset manager index left order
$ln_assetmanager='ቋሚ ንብረት ሃላፊ';
$ln_welcome='እንኳን ደህና መጡ';
$ln_general='አጠቃላይ';
$ln_home='ወደ ዋና';
$ln_about='ስለ እኛ';
$ln_contact='መገናኛ';
$ln_birr="ብር";
$ln_registerAsset='ዕቃ ምዝገባ';
$ln_withdrawAsset='ዕቃ ወጪ ማድረግ';
$ln_viewAssetInformation='የ ዕቃ መረጃ ማየት';
$ln_generateReport='ሪፖርት ማዘጋጀት';
$ln_approveReturnedAsset='ተመላሽ ዕቃ መቀበል';
$ln_viewAnnouncement='ማስታወቂያ ማየት';
$ln_updateAccount='የይለፍ ቃል መቀየር';
$ln_dear='የተከበሩ';
$ln_prepareAnnouncementTop="ማስታወቂያ ማዘጋጀት";
$ln_prepareAnnouncementAdd="አዘጋጅ";
$ln_prepareAnnouncementSucess="ማስታወቂያዉን በተሳካ ሁኔታ አዘጋጅተዋል";
$ln_prepareAnnouncementfail="የማስታወቂያ ማብቂያ ቀን ቢያንስ ከዛሬ እኩል መሆን አለበት";
$ln_withdrawAssetfor='ዕቃ ወጭ አድርግ ለ';
$ln_seeAllalert='ሁሉንም ማስጠንቀቂያ እይ';
$ln_noNotification='ምንም ማሳወቂያ የለም';
$ln_deleteAnnouncementSucess="በትክክል ማስታወቂያውን አጥፍተዋል";
$ln_asset='ዕቃ';
$ln_expiredAnnouncement="ቀኑ ያለፈ ማስታወቂያ";
$ln_activeAnnouncement="ቀኑ ያላለፈ ማስታወቂያ";
$ln_registerAssetNegative="የ ዕቃው ብዛት ቢያንስ ከ 0 በላይ መሆን አለበት";
$ln_registerMoneyNegative="የ ዕቃው ዋጋ ቢያንስ ከ 0 በላይ መሆን አለበት";

//body of index of asset manager
$ln_generalInformation='ኣጠቃላይ መረጃ';
$ln_dashboard='ዳሽቦርድ';
$ln_assetItem='የዕቃ አይነት';
$ln_approvedRequest='ምላሽ ያገኙ ጥያቄዎች';
$ln_asset='ዕቃ';
$ln_logout='ዉጣ';

//Register asset for asset manager
$ln_registerAssetTitle='ዕቃ ምዝገባ';
$ln_registerAssetInnerTitle='ፎርሙን ሙላ';
$ln_assetName='የዕቃው ኣይነት ዝርዝር ';
$ln_assetModel='የዕቃዉ ሞዴል';
$ln_quantity='ብዛት';
$ln_price='የኣንዱ ዋጋ';
$ln_submit='መዝግብ';
//sucees and error message for register asset
$ln_success='ተሳክቷል';
$ln_SuccessMessageUpdate='ይህ ዕቃ ከዚህ በፊት ተመዝግቧል ብዛቱን ተስተካክሏል.<br> አሁን ያሎት';
$ln_SuccessMessageRegistered='በትክክል ገቢ ሆኗል!!!';
$ln_SuccessLast=' ነው';


//View asset information
$ln_viewAssetTitle='ኣጠቃላይ ዕቃ';
$ln_assetId='የዕቃዉ መለያ';
$ln_viewAssetName='የዕቃው ስም';
$ln_viewAssetModel='የዕቃው ሞዴል';
$ln_totalPrice='አጠቃላይ ዋጋ ';
$ln_regDate='የተመዘገበበት ቀን';


//Generate Report
$ln_generateReportTitle='ሪፖርት ማዘጋጀት';
$ln_generateReportInnerTitle='የሪፖርት አይነት ምረጥ';
$ln_reportType='የሪፖርት አይነት';
$ln_reportContent='የሪፖርት ይዘት';
$ln_weeklyReport='ሳምንታዊ ሪፖርት';
$ln_monthlyReport='ወራዊ ረፖርት';
$ln_threeMonthReport='የ ሶስት ወር ሪፖርት';
$ln_sixMonthReport='የ ስድስት ወር ሪፖርት';
$ln_yearReport='ዓመታዊ ሪፖርት';
$ln_generateReportPlaceHolder='ስለ ሪፖርቱ ትንሽ መግለጫ ፃፍ';
$ln_fail='አልተሳካም';
$ln_generateReportTheSameDay='ይህን ሪፖርት ዛሬ ስላዘጋጁ በድጋሜ ማዘጋጀት አይችሉም';
$ln_generateReportNoWithdrawNoRegister='ወጭም ሆነ ገቢ የሆነ ዕቃ የለም';
$ln_generateReportWithdrawNoRegister='ገቢ የሆነ ዕቃ የለም ነገር ግን ወጭ የሆኑትን አዘጋጅተዋል.';
$ln_generateReportWithdrawRegister='ሪፖርቱን በተሳካ ሁነታ አዛጋጅተዋል';
$ln_generateReportNOWithdrawRegister='ወጭ የሆነ'
        . ' ዕቃ የለም ነገር ግን ገቢ የሆትን አዘጋጅተዋል';
//create Account
$ln_createAccountFirstName='የተጠቃሚ ስም ';
$ln_createAccountMiddleName='የአባት ስም ';
$ln_createAccountConfirmEmail='ማረጋገጫ ኢሜይል ';
$ln_createAccountConfirmPassword='ማረጋገጫ የይለፍ ቃል ';
$ln_createAccountUserType='የተጠቃሚ አይነት ';
$ln_createAccountTelephone='ስልክ ቁጥር ';
$ln_createAccountAdress='አድራሻ ';
$ln_createAccountOccupation='የስራ ድርሻ ';
$ln_createTitle='ፎርሙን ይምሉ';
$ln_createAccountSex='ፆታ';
$ln_createAccountSelectUser='የተጠቃሚ አይነት ምረጥ';
$ln_createAccountSelect='የተጠቃሚ አይነት ይምረጡ';
$ln_createAccountTop='የተጠቃሚ አካዉንት መክፈት';
$ln_createAccountSuccess='ለተጠቃሚው በትክክል አካዉንት ከፍተዋል';
$ln_createAccountFail='የተጠቃሚዉ ኢሜይል ስላለ አካውንቱ አልተከፈተም';

//withdraw asset
$ln_withdrawAssetInnerTitle='ጠቅላላ ጥያቄዎች ከንብረት ተጠቃሚ';
$ln_withdrawAssetAssetId='የዕቃው መለያ';
$ln_withdrawAssetAssetDate="ወጪ የሆነበት ቀን";
$ln_action="እርምጃ";
$ln_approveReturnedAssetTooltip="ምላሽ አድርግ";
$ln_withdrawAssetAssetUserName='የንብረት ተጠቃሚው ስም';
$ln_withdrawAssetAssetOccupation='የስራ ድርሻ';
$ln_withdrawAssetAssetPrepare_date='የተዘጋጀበት ቀን';
$ln_withdrawAssetAssetAssetName='የዕቃው ስም';
$ln_withdrawAssetAssetAssetType='የዕቃው አይነት';
$ln_withdrawAssetAssetAssetQuantity='ብዛት';
$ln_withdrawAssetAssetPurpose='ምያወጣበት ምክኒያት';
$ln_withdrawAssetAssetAction='ዕርምጃ';
$ln_withdrawAssetAssetActionwithdraw='ወጭ';
$ln_withdrawAssetAssetActionborrow='ውሰት';
$ln_withdrawAssetnoapproved='ይቅርታ ለግኤው ምላሽ የተሰጣቸው ጥያቄዎች የሉም';
$ln_withdrawAssetnoasset='ይቅርታ ለግዜው በቂ ዕቃ ስለለላ ትንሽ ይጠብቁ';
$ln_withdrawAssetRequest='ጥያቄ';
$ln_withdrawAssetYes='አዎ';
$ln_withdrawAssetNo='አይ';
$ln_withdrawAssetNotEnough='ለግዜው በቂ ዕቃ ስለሌለን እባክዎ ትንሽ ይጤብቁን.';
$ln_withdrawAssetSuccess='በትክክል ዕቃዉን ወጪ አድርገዋል ወጪ ያረጉት ለ  ';
$ln_noNotificationRequest='ለግዜው ምንም ጥያቄ የለም';
//view announcement 
$ln_viewAnnouncementNoannouncement="ይቅርታ ዕስካሁን ምንም የወጣ ማስታወቂያ የለም!! .";
$ln_viewAnnouncementTopTitle="ጠቅላላ ማስታወቂያ";
$ln_viewAnnouncementpreparedby="የተያዘጋጀው በ:";
$ln_viewAnnouncementPreparedOn="ቀን :";
$ln_viewAnnouncementTitle="ርዕስ :";


// change password

$ln_changePasswordInnerTitle='ፎርሙን ይሙሉ';
$ln_changePasswordTitle="የ ይለፍ ቃል መቀየር ：";
$ln_changePasswordCurrentpassword='አሁን የሚጠቀሙበት የይለፍ ቃል ：';
$ln_changePasswordNewpassword='አዲሱ የይለፍ ቃል ：';
$ln_changePasswordConfirmpassword='ማረጋገጫ የይለፍ ቃል ：';
$ln_changePasswordSucess='የይለፍ ቃሎን በትክክል ቀይረዋል!!!.';
$ln_changePasswordfail=' ይቅርታ አሁን የሚጠቀሙበትን የይለፍቃል ተሳስተዋል!!.';
$ln_changePasswordcon='ይቅርታ ያስገቡት የማረጋገጨ የይለፍ ቃል አይመጠንም!!!.';

//asset user page
//index of asset user
$ln_totalAsset='አጠቃላይ ዕቃ';
//letf navigation
$ln_assetUserTitle='ንብረት ተጠቃሚ';
$ln_prepareRequest='ጥያቄ ማቅረብ';
$ln_prepareProblemReport='ያጋጠመኝ ችግር ሪፖርት';
$ln_viewFeedback='ምላሽ ማየት';
$ln_viewMyAsset='የኔን ዕቃ ማየት';
$ln_changePassword='የይለፍ ቃለን መቀየር';

//prepare request
$ln_requestAssetName='የ ዕቃው ስም：';
$ln_requestmaterialType='የ ዕቃው አይነት';
$ln_requestPurpose='ወጪ ማድረግ የፈለጉበት ምክኒያት：';
$ln_requestquantity='የ ዕቃዉ ብዛት ：';
$ln_requestsucess=' ጥያቄውን በትክክል አቅርበዋል';


//prepare problem report
$ln_problemReportTopTitles=' ያጋጠመኝን ችግር ማቅረብ';
$ln_problemReportTitle='ርዕስ';
$ln_prepareProblemReportContent='ያጋጠሞት ችግር ';
$ln_prepareProblemReportContentplaceholder='ያጋጠሞትን ችግር ጻፉ ';
$ln_problemReportSuccess='ያጋጠሞትን ችግር በትክክል አቅርበዋል ምላሹን ይጠብቁ ';


//Asset user page
//left link


//view feedback
$ln_viewFeedbackTopTitle='የኔ ምላሽ ';
$ln_viewFeedbackInnerTitle='የ ጥያቄዎት ምላሽ ';
$ln_viewFeedbackTo='ለ :';
$ln_viewFeedbackTitle='ርዕስ : ';
$ln_viewFeedbackAnswered='ምላሽ የተሰጠው በ ';
$ln_viewFeedbackDelete='ለማጥፋት ይህችን ይጫኑ :';
$ln_viewFeedbackPreparedon='ምላሽ የተሰጠበት ቀን :';
$ln_viewFeedbackDayago=' ቀን በፊት';
$ln_viewFeedbackYearago=' ዓመት በፊት';
$ln_viewFeedbackMonthago=' ወራት በፊት';
$ln_viewFeedbackMinuteago=' ደቂቃ በፊት';
$ln_viewFeedbackSecondago=' ሴኮንድ በፊት';
$ln_viewFeedbackbefore=' ከ ';
$ln_viewFeedbackHourago=' ሰዓት በፊት ';
$ln_viewFeedbackDeleteSucess=' ተሳክቷል በትክክል ምላሽዎትን አጥፍተዋል ';

//Property manager page
$ln_propertyManger=' ግዥ እና ንብረት ሃላፊ';
$ln_propertyMangerManageUsers='ተጠቃሚ መቆጣጠር';
$ln_propertyMangerViewproblemreport='የቀረቡ ችግሮችን መመልከት';
$ln_propertyManagerApproveReport=' የቀረቡ ሪፖርትን ማጽደቅ';
$ln_propertyMangerPrepareAnnouncement='ማስታወቂያ ማዘጋጀት';
$ln_propertyMangerCreateAccount="ለተጠቃሚ አካዉንት መክፈት";
$ln_propertyMangerDeactivateUser='የተጠቃሚ አካውንት መዝጋት';
$ln_propertyMangerDeactivateAssetUser='የዕቃ ተጠቃሚ አካዉንት መዝጋት';
$ln_propertyMangerDeactivateAssetManager='የዕቃ ክፍል አካዉንት መዝጋት';
$ln_propertyMangerActivateUser='የተዘጉ አካውንት መክፈት';
$ln_propertyMangerActivateAssetUser='የዕቃ ተጠቃሚ አካዉንት መክፈት';
$ln_propertyMangerActivateAssetManager='የዕቃ ተቆጣጣሪ አካዉንት መክፈት';
$ln_propertyMangerViewUser='የተጠቃሚ መረጃዎችን ማየት';
$ln_propertyMangerViewAssetUser='የዕቃ ተጠቃሚ መረጃ ማየት';
$ln_propertyMangerviewAssetManager='የዕቃ ተቆጠጣሪ መረጃ ማየት';
$ln_propertyMangerViewAssetTitle='ጠቅላላ የዕቃ መረጃ';
$ln_propertyMangerViewAssetExport='ገልብጥ';
$ln_propertyManagerRequest='ጥያቄዎች';
$ln_propertyMangerAssetUsers='የ ዕቃ ተጠቃሚ';
$ln_propertyMangerAsset='ዕቃዎች';
$ln_propertyMangerNotification='የ ዕቃ አይነቶች ብዛታቸው ከ 10 በታች ነው';
$ln_propertyMangerDeleteTooltip='ይህን ሪፖርት አጥፋ';
$ln_propertyMangerReplayTooltip='ለዚህ ሪፖርት ምላሽ ስጥ';
$ln_propertyMangerViewproblemreportTitle='የዕቃ ተጠቃሚ ችግር ሪፖርት';
$ln_propertyMangerFeedback='ምላሽ：';
$ln_propertyMangerunreplay='ምላሽ ያልተሰጠው ሪፖርት';
$ln_propertyMangerreplay='ምላሽ የተሰጠው ሪፖርት';
$ln_propertyMangerDeleteReportsuccess='በተሳካ ሁኔታ ረፖርቱን አጥፍተዋል ';
$ln_propertyMangerViewUserFullname='ሙሉ ስም ';
$ln_propertyMangerViewUseroccupation='የስራ ድርሻ';
$ln_propertyMangerViewUserPhone='ስልክ ቁጥር';
$ln_propertyMangerViewUserAdress='አድራሻ';
$ln_propertyMangerViewUserSex='ፆታ';
$ln_propertyMangerViewUserTitle ='ጠቅላላ የ ዕቃ ተጠቃሚ መረጃ';
$ln_withdrawAppoitement='የቀጠሮ ቀን';
$ln_withdrawAssetItem='የዕቃ አይነት አለ ';
$ln_withdrawAssetInfo='መረጃ!';
$ln_withdrawAssetReturnMessage=' በዚህ ሳምንት መመለስ ያለበት ';
$ln_showMore='በደንብ አሳይ';

//lost asset
$ln_lostAssetNoAssetName=' ይቅርርታ አልተሳካም  ይህን ዕቃ  ወጪ አላደረጉም';

$ln_lostAssetAccountNumbernotFound='ያስገቡት የባንክ አከውንት ትክክል አይደለም';
$ln_lostAssetAccountPaswordnotFound ='የ አካውንት ይለፍ ቃል ትክክል አይደለም';
$ln_lostAssetAccountNotEnoughmoney=' ይቅርታ ከአካውንቱ ላይ በቂ ሂሳብ የሎትም';
$ln_lostAssetAccountPayed=' በትክክ ክፍያዉን ፈጽመዋል የከፈሉት ';
$ln_download="አውርድ";
$ln_assetUserName="ሙሉ ስም ";
$ln_appoitementDate="የቀጠሮ ቀን";
$ln_serialNumber="ስሪያል ቁጥር";
$ln_returnAssetFrom= "ዕቃ ምላሽ አድርግ ከ ";
$ln_approveReturnAssetnegative="የዕቃው ብዛት ከ 0 በላይ መሆን አለበት";
$ln_approveReturnAssetMore="እባክዎ የዕቃዉን ብዛት ይቀንሱት";
$ln_approveReturnAssetSuccess="ተሳክቷል ዕቃዉን በሚገባ ምላሽ አድርገዋል";
$ln_changePasswordCurrent="አሁን የሚጠቀሙበትን የይለፍ ቃል ያስገቡ";
$ln_changePasswordNew="አዲሱን የይለፍ ቃል ያስገቡ";
$ln_changePasswordConfirm="ማረጋገጫ የይለፍ ቃል ያስገቡ";
?>

