<?php
//login
$ln_bookFine='Adabii Maalaqaa Kitaabaf';
$ln_email='Imeelii';
$ln_password='Jechadarbii';
$ln_language='Qooqa';
$ln_loginTitle='Gucaa Seensaa';
$ln_loginInnerTitle='Gocaa guuti';
$ln_login='Seenii';
$ln_cancel='Balleesi';
$ln_requestAppoitement="Guyyaa Gaaffiin dhiyaate";
$ln_lostpassword='Jechadarbii dagatee??';
$ln_loginIncorectTitle='Hin Milkoofne';
$ln_viewWithdraw="Meeshaa ba'e ilaalluuf";
$ln_loginIncorectEmailMessage='Dhiifama Imeliin galchitan dogogora：：';
$ln_loginIncorectPasswordMessage='Dhiifama jechi darbii keessaan sirri miti：：';
$ln_loginDeactive='Dhiifama akawuntiinkkun dalaga hin jiru';
$ln_withdrawAssetPastDate="Guyyaan itti galchitan kan har'a caalu qaba";
$ln_withdrawAssetEmptyDate="Guyyaa meeshaan itti ba'e hin guutamne";
$ln_lostAssetNoAssetQuantityNegative="Baay'inni meeshaa 1 ol ta'u qaba";
$ln_propertyMangerApproveRequest="Gaaffiiwwan Mirkanneessu";
$ln_createAccountFailPhone="Lakk.bilbilagalchiitan tajaajila kennaa jirra";
$ln_approve="mirkanneessi";
$ln_reject="Kuufisii";
$ln_lostAssetNoAssetMoreQuantity="Dhiifama Meeshaa hammanaa hin baasne";
$ln_preparedDate="Guyyaa itti qophaa'e ";
$ln_rejectedReportNotification="yaadachiisaa gabaasaa hin mirkaanoofne ";
$ln_approvedReportNotification="Yaadachiisaa gabaasaa mirkaana'ee ";
$ln_rejectReportSuccess="Gabaasa dhiyaate hin mirkanneessin";
$ln_approveReportSuccess="Gabaasa dhiyaate mirkanneessi ";
$ln_assetPayment='Kaffaaltii raawwaachuf';
$ln_generalAssetUser="Fayyaadamtoota qabeenya waliigalaa";
$ln_report="Gabaasa";
$ln_problemReport="Rakkoolee";
$ln_giveFeedback="Dubdeebii kenni";
$ln_generalAssetmanager="Hoganaa qabeenya walii galaa";
$ln_generalAssetUserRequest="Gaaffiiwwan Fayyaadamtoonni dhiyeesan";
$ln_approveReportTop="Gabaasa Mirkanneessu";
$ln_approveReportPrepareBy="maqaa qopheesicha";
$ln_approveReportPrepareType="Gosaa gabaasaa";
$ln_approveReportPrepareDescription="ibsaa";
$ln_approveReportPrepareDate="Guyyaa Gabaasni qophaahe itti mirkaana'ee";
$ln_lostAssetPayement='Qabeenya badee kafaaluuf';
$ln_accountNumber='Lakk. Herrega';
$ln_AccountPassword='Jecha darbii';
$ln_notification='Yadaachisaa';
//asset manager index left order
$ln_assetmanager='Hoganaa Qabeenya dhabaatoo';
$ln_welcome='Baga Nagaan Dhuftan';
$ln_general='Cuunfaa';
$ln_home='Fuula Jalqabaa';
$ln_about='Waahee Keenyaa';
$ln_contact='Nu Quunamuuf';
$ln_birr="Qarshii";
$ln_registerAsset='Meeshaa Galmeessuu';
$ln_withdrawAsset='Meeshaa baasu';
$ln_viewAssetInformation='Oddeeffanoo meeshaa illaalluu';
$ln_generateReport='Gabaasa qopheesuu';
$ln_approveReturnedAsset='Meeshaa deebihe Mirkanneessu';
$ln_viewAnnouncement='Beeksisaa ilaalli';
$ln_updateAccount='Jecha darbii Haroomsuuf';
$ln_dear='Kabaajamoo';
$ln_prepareAnnouncementTop="Beeksisaa qopheesuu";
$ln_prepareAnnouncementAdd="Qopheessi";
$ln_prepareAnnouncementSucess="Beeksisiicha haala gaariin qopheesitanitu";
$ln_prepareAnnouncementfail="Guyyaa beeksisnii itti dhumuu yoo xiqaate har'a waliin qixa tahu qaba";
$ln_withdrawAssetfor='Meeshaa eenyuuf baasuf';
$ln_seeAllalert='Beeksisaa hundaa ilaalli';
$ln_noNotification='Beeksisuu';
$ln_deleteAnnouncementSucess="Beeksisaacha milkoominan haqxanitu";
$ln_asset='meeshaa';
$ln_expiredAnnouncement="Beeksisaa yeroonsa irra darbe";
$ln_activeAnnouncement="Beeksisaa yeroon irraa hin darbinee";
$ln_registerAssetNegative="Baayinni Meeshaa yoo xiqaate 0 ol tahu qaba";
$ln_registerMoneyNegative="Gatiin Meeshaa yoo xiqaate 0 ol tahu qaba";

//body of index of asset manager
$ln_generalInformation='Oddeeffanoo walgalaa';
$ln_dashboard='Gabaate Oddeeffanoo';
$ln_assetItem='Gosaa Meeshaa';
$ln_approvedRequest='Gaaffiiwwan deebii argatan';
$ln_asset='Meeshaa';
$ln_logout='keessaa bahuf';

//Register asset for asset manager
$ln_registerAssetTitle='Galmeessa Meeshaalee';
$ln_registerAssetInnerTitle='Gucaa Guutaa';
$ln_assetName='Gosa Meeshaa';
$ln_assetModel='Moodeela Meeshicha';
$ln_quantity="Baay'inna ";
$ln_price='Gatii meeshaa tokko';
$ln_submit='Galmeessi';
//sucees and error message for register asset
$ln_success="Milkaa'era";
$ln_SuccessMessageUpdate="Qabeenyi kun armaan dura galmaa'era baay'inniisasirratera";
$ln_SuccessMessageRegistered="Milkaa'inaan galmaa'era!!!";
$ln_SuccessLast=' dha';


//View asset information
$ln_viewAssetTitle='Qabeenya waliigalaa';
$ln_assetId='Lakk. Qabeenya addabasu';
$ln_viewAssetName='Maqaa Meeshaa';
$ln_viewAssetModel='Moodeela Meeshaa';
$ln_totalPrice='Gatii waliigalaa ';
$ln_regDate="Guyyaa itti galmaa'ee";


//Generate Report
$ln_generateReportTitle='Gabaasa qopheesuu';
$ln_generateReportInnerTitle='Gosoota Gabaasa filaadhu';
$ln_reportType='Gosa gabaasaa';
$ln_reportContent='Qabiyyee Gabaasaa';
$ln_weeklyReport='Gabaasaa torbanii';
$ln_monthlyReport="Gabaasaa ji'a";
$ln_threeMonthReport="Gabaasaa ji'a sadii";
$ln_sixMonthReport="Gabaasaa ji'a ja'a ";
$ln_yearReport='Gabaasaa waggaa';
$ln_generateReportPlaceHolder='fakkeenya gabaasaa';
$ln_fail='Hin Milkoofne';
$ln_generateReportTheSameDay="Gabaasnikun har'a waan dhiyaatef irraa deebi'u hin dandaa'u ";
$ln_generateReportNoWithdrawNoRegister="Qabeenyi ba'es ykn galee hin jiru";
$ln_generateReportWithdrawNoRegister="Meeshaan galmaa'e hin jiru, garuu baasiidhas qophaa'era.";
$ln_generateReportWithdrawRegister='Gabaasa keessan milkoominaan dhiyeeffattanittu';
$ln_generateReportNOWithdrawRegister="Meeshaan bahe hin jiru, garuu galii ta'uuf qophaa'era";
//create Account
$ln_createAccountFirstName='Maqaa fayyadamaa ';
$ln_createAccountMiddleName='Maqaa abbaa ';
$ln_createAccountConfirmEmail='Imelii mirkanneessi ';
$ln_createAccountConfirmPassword='Jecha darbii mirkanneessi ';
$ln_createAccountUserType='Gosaa Fayyadamtoota ';
$ln_createAccountTelephone='Lakk.bilbilaa ';
$ln_createAccountAdress='Teessoo ';
$ln_createAccountOccupation='Gahee hojii';
$ln_createTitle='Guca guutaa';
$ln_createAccountSex='Saala';
$ln_createAccountSelectUser='Fayyadamaa bantuuf filaadhu';
$ln_createAccountSelect='Gosa Fayyadamtoota filadhu';
$ln_createAccountTop='Herrega Fayyadamtootaf banuuf';
$ln_createAccountSuccess='Fayyadamaadhaaf herreegni banameera';
$ln_createAccountFail='Imeliin galchitan tajaajilaa waan jiruuf isiniif hin banu';

//withdraw asset
$ln_withdrawAssetInnerTitle="Gaaffilee walgalaa fayyaadamtoota irraa";
$ln_withdrawAssetAssetId='Lakk. addaa meeshaa';
$ln_withdrawAssetAssetDate="Guyyaa itti bahe";
$ln_action="Tarkaanfii";
$ln_approveReturnedAssetTooltip="Deebisi";
$ln_withdrawAssetAssetUserName='Maqaa fayyadamaa';
$ln_withdrawAssetAssetOccupation='Gita hojii';
$ln_withdrawAssetAssetPrepare_date="Guyyaa itti qophaa'e :";
$ln_withdrawAssetAssetAssetName='Maqaa Meeshaa';
$ln_withdrawAssetAssetAssetType='Gosaa Meeshaa';
$ln_withdrawAssetAssetAssetQuantity="Baay'ina";
$ln_withdrawAssetAssetPurpose='Sababa baheef';
$ln_withdrawAssetAssetAction='Tarkaanfii';
$ln_withdrawAssetAssetActionwithdraw='Baasuuf';
$ln_withdrawAssetAssetActionborrow='Ergifachuu';
$ln_withdrawAssetnoapproved='Dhiifama yeroof deebiin isiniif laatame hin jiru';
$ln_withdrawAssetnoasset='Dhiifama yeroof meeshaa gahaa waan hin qabneef xiqqo nuuf obsaa';
$ln_withdrawAssetRequest='Gaaffii';
$ln_withdrawAssetYes='Eeyyee';
$ln_withdrawAssetNo='Lakki';
$ln_withdrawAssetNotEnough='Dhiifama yeroof meeshaa gahaa waan hin qabneef xiqqo nuuf obsaa .';
$ln_withdrawAssetSuccess='Meeshaan  baafameera nama baafameef..';
$ln_noNotificationRequest='Yeroof gaaffiin dhiyaate hin jiru';
//view announcement 
$ln_viewAnnouncementNoannouncement="Dhiifama, ammaaf beeksisni bahe hin jiru !! .";
$ln_viewAnnouncementTopTitle="Beeksisa waliigalaa";
$ln_viewAnnouncementpreparedby="Qopheessaan:";
$ln_viewAnnouncementPreparedOn="Guyyaa :";
$ln_viewAnnouncementTitle="Mata duree :";


// change password

$ln_changePasswordInnerTitle='Guca guutamu';
$ln_changePasswordTitle="Jecha darbii jijjiiruuf ：";
$ln_changePasswordCurrentpassword='Jecha darbii amma fayyadamaa jirtan：';
$ln_changePasswordNewpassword='Jecha darbii haaraa ：';
$ln_changePasswordConfirmpassword='Jecha darbii kee irra deebiin galchi：';
$ln_changePasswordSucess='Jechi darbii keessan jijjiirameera!!!.';
$ln_changePasswordfail=' Dhiifama jecha darbii keessan dogoggora!!.';
$ln_changePasswordcon='Dhiifama jechi darbii galchiitan sirrii miti!!!.';

//asset user page
//index of asset user
$ln_totalAsset='Meeshaalee waliigalaa';
//letf navigation
$ln_assetUserTitle='Fayyadamtoota Qabeenya';
$ln_prepareRequest='Gaaffii dhiyeessuu';
$ln_prepareProblemReport='Rakkoo mudate dhiyeeffachuuf';
$ln_viewFeedback='Dubdeebii ilaaluu';
$ln_viewMyAsset='Qabeenya kiyya ilaaluu';
$ln_changePassword='Jecha darbii jijjiiruu';

//prepare request
$ln_requestAssetName='Maqaa Meeshaa：';
$ln_requestmaterialType="Gosa Meeshaa: ";
$ln_requestPurpose="Sababa ittiin bahuuf ";
$ln_requestquantity="Baay'inaa Meeshaa ";
$ln_requestsucess="Gaaffiin keessan ergameera ";


//prepare problem report
$ln_problemReportTopTitles='Rakkoo mudate dhiyeessuu';
$ln_problemReportTitle='Mata duree';
$ln_prepareProblemReportContent='Rakkoo isin mudate ';
$ln_prepareProblemReportContentplaceholder="Rakkoo isin mudate barreessaa ";
$ln_problemReportSuccess="Rakkoo isin mudate Milkaa'inan dhiyeeffattanittu";


//Asset user page
//left link


//view feedback
$ln_viewFeedbackTopTitle='Dubdeebii naf kenname：';
$ln_viewFeedbackInnerTitle="Deebii gaaffilee dhiyaatanii";
$ln_viewFeedbackTo='..dhaf:';
$ln_viewFeedbackTitle='Matduree Dubdeebii： ';
$ln_viewFeedbackAnswered='Deebiin kankenne ';
$ln_viewFeedbackDelete='Haquuf :';
$ln_viewFeedbackPreparedon='Guyyaa deebiin itti latamee :';
$ln_viewFeedbackDayago=' Guyyoota dura';
$ln_viewFeedbackYearago=' waggaa dura';
$ln_viewFeedbackMonthago="Ji'a dura ";
$ln_viewFeedbackMinuteago=' Daqiiqa dura';
$ln_viewFeedbackSecondago=' Seekondii dura';
$ln_viewFeedbackbefore=' dura';
$ln_viewFeedbackHourago=' Yeroo muraasa dura';
$ln_viewFeedbackDeleteSucess="milkaa'inan haqxanitu";

//Property manager page
$ln_propertyManger=' Hoggaana waliigalaa';
$ln_propertyMangerManageUsers="Fayyaadamtoota to'achuuf ";
$ln_propertyMangerViewproblemreport='Rakkoolee dhiyaatan ilaalluuf';
$ln_propertyManagerApproveReport=' Gabaasa dhiyaate Mirkanneessuf';
$ln_propertyMangerPrepareAnnouncement='Beeksisaa qopheesuu';
$ln_propertyMangerCreateAccount="Herrega Fayyaadamtootaf banuf";
$ln_propertyMangerDeactivateUser='Herrega fayyaadama cufuf';
$ln_propertyMangerDeactivateAssetUser='Herrega Fayyaadamtoota cuufuf';
$ln_propertyMangerDeactivateAssetManager='Herrega tohata cuufuf';
$ln_propertyMangerActivateUser='Herrega cuufamee banuuf';
$ln_propertyMangerActivateAssetUser='Fayyaadamtootaf herrega banu';
$ln_propertyMangerActivateAssetManager='Tohataaf herrega banu';
$ln_propertyMangerViewUser='Oddeeffanoo Fayyaadamtoota ilaalluuf';
$ln_propertyMangerViewAssetUser='Oddeeffanoo Fayyaadamtoota beekuuf';
$ln_propertyMangerviewAssetManager='Oddeeffanoo tohata beekuuf ';
$ln_propertyMangerViewAssetTitle='Oddeeffanoo walgalaa Meeshaalee';
$ln_propertyMangerViewAssetExport='Garaagalchi';
$ln_propertyManagerRequest='Gaaffiiwwan dhiyaatan';
$ln_propertyMangerAssetUsers='Fayyaadamtoota';
$ln_propertyMangerAsset='Meeshaalee';
$ln_propertyMangerNotification='Gosoonni Meeshaa jiraanii 10 qofa';
$ln_propertyMangerDeleteTooltip='Gabaasa kana haqi';
$ln_propertyMangerReplayTooltip='Gabaasichaf deebii kenni';
$ln_propertyMangerViewproblemreportTitle='Gucaa rakkoo dhiyaate ibsu';
$ln_propertyMangerFeedback='Dubdeebii：';
$ln_propertyMangerunreplay='Gabaasa deebii hin arganne';
$ln_propertyMangerreplay='Gabaasa deebii argate';
$ln_propertyMangerDeleteReportsuccess='Gabaasni dhiyaate milkoominan haqameera';
$ln_propertyMangerViewUserFullname='Maqaa guutuu';
$ln_propertyMangerViewUseroccupation='Gita hojii';
$ln_propertyMangerViewUserPhone='Lakk. Bilbila';
$ln_propertyMangerViewUserAdress='Teessoo';
$ln_propertyMangerViewUserSex='Saalaa';
$ln_propertyMangerViewUserTitle ='Oddeeffanoo walgalaa meeshaa';
$ln_withdrawAppoitement='Guyyaa beelama';
$ln_withdrawAssetItem='Akkaakuu meeshaa ';
$ln_withdrawAssetInfo='Oddeeffanoo!';
$ln_withdrawAssetReturnMessage=' Torbee kana keessaa deebihu kan qaban ';
$ln_showMore='Guutumatti ilaalluuf';

//lost asset
$ln_lostAssetNoAssetName=' Dhiifama Meeshaan bahe hin argamne';

$ln_lostAssetAccountNumbernotFound='Lakk.herrega galchitani sirri miti';
$ln_lostAssetAccountPaswordnotFound ='Jechadarbii herrega keessaani hin argamne';
$ln_lostAssetAccountNotEnoughmoney=' Dhiifama herregni keessaan gaha miti：：';
$ln_lostAssetAccountPayed=' Kaffaalti milkaanahera ';
$ln_download="Buusi";
$ln_assetUserName="maqaa guutuu ";
$ln_appoitementDate="Guyyaa beelama";
$ln_serialNumber="Lakk. adda Meeshaa ibsu";
$ln_returnAssetFrom= "Gucaa Meeshaan ittin deebi'uu";
$ln_approveReturnAssetnegative="Baay'inii Meeshaa duwaaol ta'u qaba";
$ln_approveReturnAssetMore="Dhiifama baay'inaa Meeshaa hir'isaa";
$ln_approveReturnAssetSuccess="Meeshaan deebi'ee Mirkannaa'era";
$ln_changePasswordCurrent="Jechadarbii fayyaadama jirtan galchaa";
$ln_changePasswordNew="Jechadarbii haaraa galchaa";
$ln_changePasswordConfirm="Mirkanneessuf irraa deebiin Jechadarbii galchaa";
?>

