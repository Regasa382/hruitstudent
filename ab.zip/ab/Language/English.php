<?php
//login
$ln_bookFine='Fine for Book';
$ln_email='Email';
$ln_password='Password';
$ln_language='Language';
$ln_loginTitle='Login Form';
$ln_loginIncorectTitle='Fail';
$ln_requestAppoitement="Requested Date";
$ln_loginIncorectEmailMessage='Sorry Such Email not found';
$ln_loginIncorectPasswordMessage='Sorry password not match';
$ln_loginDeactive='Sorry your account is Deactivated Please contact to property manager';
$ln_loginInnerTitle='Please Fill The Form';
$ln_login='Login';
$ln_cancel='Cancle';
$ln_viewWithdraw="View Withdraw";
$ln_approve="Approve";
$ln_reject="Reject";
$ln_createAccountFailPhone="This Phone Number already Exist";
$ln_propertyMangerApproveRequest="Approve Request";
$ln_lostpassword='Lost My password ??';
$ln_assetPayment='Payment';
$ln_lostAssetPayement='PAYMENT FORM';
$ln_accountNumber='Account Number';
$ln_AccountPassword='Account Password';
$ln_lostAssetNoAssetMoreQuantity="Sorry you are not take such ammount of computer";
$ln_withdrawAssetPastDate="the Retuned date Must be Greater than today";
$ln_withdrawAssetEmptyDate="The Returned Date Cannot Be Empty";
$ln_lostAssetNoAssetQuantityNegative="Asset Quantity atleast greater than Zero";
//asset manager index left order
$ln_assetmanager='InventoryManager';
$ln_report="Report";
$ln_problemReport="Problem Report";
$ln_notification='Notification';
$ln_welcome='Welcome';
$ln_preparedDate="Prepared Date";
$ln_rejectedReportNotification="Rejected Report ";
$ln_approvedReportNotification="Approved Report";
$ln_generalAssetUser="General Asset User";
$ln_generalAssetmanager="General Asset Manager";
$ln_generalAssetUserRequest="General Request From Asset Users";
$ln_approveReportTop="Approve Report";
$ln_approveReportPrepareBy="Prepared By";
$ln_giveFeedback="Give Feedback";
$ln_approveReportPrepareType="Report type";
$ln_approveReportPrepareDescription="Description";
$ln_approveReportPrepareDate="Prepare Date";
$ln_approveReportSuccess="You are approve report sucessfully";
$ln_general='General';
$ln_home='Home';
$ln_about='About';
$ln_birr="Birr";
$ln_contact='Contact';
$ln_registerAsset='Register Asset';
$ln_withdrawAsset='Withdaw Asset';
$ln_viewAssetInformation='View Asset Information';
$ln_generateReport='Generate Report';
$ln_approveReturnedAsset='Approve Returned Asset';
$ln_viewAnnouncement='View Notification';
$ln_updateAccount='Change Password';
$ln_dear='Dear';
$ln_withdrawAssetfor='Withdraw Asset for';
$ln_seeAllalert='See All Allerts';
$ln_noNotification='No Notification';
$ln_asset='Asset';

//body of index of asset manager
$ln_generalInformation='General Information';
$ln_dashboard='DASHBOARD';
$ln_assetItem='Asset Item';
$ln_approvedRequest='Approved Request';
$ln_asset='Asset';
$ln_logout='Logout';
$ln_prepareAnnouncementTop="Prepare Notification";
$ln_prepareAnnouncementAdd="Add Announcement";
$ln_prepareAnnouncementSucess="You are successfully prepared announcement";
$ln_prepareAnnouncementfail="The Expire date Atleast equal to today";
//Register asset for asset manager
$ln_registerAssetTitle='Register Asset';
$ln_registerAssetInnerTitle='Fill The Form';
$ln_assetName='Detailed description of Articles or Property ';
$ln_assetModel='Asset Model';
$ln_quantity='Quantity';
$ln_price='Unit Price';
$ln_submit='Submit';
$ln_expiredAnnouncement="Expired Notification";
$ln_activeAnnouncement="Active Notification";
$ln_registerAssetNegative="Asset Quantity must be greater than 0";
$ln_registerMoneyNegative="Asset Price must be greater than 0";
$ln_deleteAnnouncementSucess="You are Sucessfully delete the Announcement";

//sucees and error message for register asset
$ln_success='Success';
$ln_SuccessMessageUpdate='Your asset Already exit Updated Suceessfully.<br>you have';
$ln_SuccessMessageRegistered='you are register!!!';
$ln_SuccessLast='';

//View asset information
$ln_viewAssetTitle='General Asset';
$ln_assetId='Asset Id';
$ln_viewAssetName='Asset Name';
$ln_viewAssetModel='Asset Model';
$ln_totalPrice='Total Price';
$ln_regDate='Reg_Date';


//Generate Report
$ln_generateReportTitle='Generate Report';
$ln_generateReportInnerTitle='Select Report Type';
$ln_reportType='Report Type';
$ln_reportContent='Report Content';
$ln_weeklyReport='Weekly Report';
$ln_monthlyReport='Monthly Report';
$ln_threeMonthReport='Three Month Report';
$ln_sixMonthReport='Six Month Report';
$ln_yearReport='Yearly Report';
$ln_generateReportPlaceHolder='Write some Description of Report';
$ln_fail='';
$ln_generateReportTheSameDay='Sorry You are prepare this report today now it is not aviallable';
$ln_generateReportNoWithdrawNoRegister='There is no either withdraw nor register asset';
$ln_generateReportWithdrawNoRegister='There is not Registered asset but you are prepare  withdraw report .';
$ln_generateReportWithdrawRegister='You are successfully prepared report.';
$ln_generateReportNOWithdrawRegister='There is not Withdraw asset but you are prepare  about registered asset .';

//withdraw asset
$ln_withdrawAssetInnerTitle='General Request From Asset Users';
$ln_withdrawAssetAssetId='Request_Id';
$ln_withdrawAssetAssetDate="Withdraw Date";
$ln_withdrawAssetAssetUserName='Asset User Name';
$ln_withdrawAssetAssetOccupation='Occupation';
$ln_withdrawAssetAssetPrepare_date='Prepared Date';
$ln_withdrawAssetAssetAssetName='Asset Name';
$ln_withdrawAssetAssetAssetType='Asset Type';
$ln_withdrawAssetAssetAssetQuantity='Quantity';
$ln_withdrawAssetAssetPurpose='Withdraw Purpose';
$ln_withdrawAssetAssetAction='Action';
$ln_withdrawAssetAssetActionwithdraw='Withdraw';
$ln_withdrawAssetAssetActionborrow='Borrow';
$ln_withdrawAssetnoapproved='Sorry Currently there is no approved Request';
$ln_withdrawAssetnoasset='Sorry Currently we have not Enough asset to withdraw';
$ln_withdrawAssetYes='Yes';
$ln_withdrawAssetNo='No';
$ln_withdrawAssetRequest='Request';
$ln_noNotificationRequest='No Request';
$ln_withdrawAssetNotEnough='Currently we have not Enough asset please wait until we get the asset.';
$ln_withdrawAssetSuccess='you are successfully withdraw asset for the user';
//view announcement 
$ln_viewAnnouncementNoannouncement="Sorry Still now There is no Announcemnt Thankyou!! .";
$ln_viewAnnouncementTopTitle="General Announcment";
$ln_viewAnnouncementpreparedby="Prepared by:";
$ln_viewAnnouncementPreparedOn="Prepared On:";
$ln_viewAnnouncementTitle="Title";
$ln_createTitle='Fill The Form';


// change password
$ln_changePasswordTitle="Change My Password";
$ln_changePasswordInnerTitle='Fill the Form';
$ln_changePasswordCurrentpassword='Current Password';
$ln_changePasswordNewpassword='New Password';
$ln_changePasswordConfirmpassword='Confirm Password';
$ln_changePasswordSucess='change your password successfully!!!.';
$ln_changePasswordfail='You enter incorrect password try again!!.';
$ln_changePasswordcon='Confirmation password not correct try again!!!.';
//asset user page
//index of asset user
$ln_totalAsset='Total Asset';
//letf navigation
$ln_assetUserTitle='Asset User';
$ln_prepareRequest='Send Request';
$ln_prepareProblemReport='Report Problem';
$ln_viewFeedback='View FeedBack';
$ln_viewMyAsset='View My Asset';
$ln_changePassword='Change Password';
$ln_action="Action";
//prepare request
$ln_requestAssetName='Asset Name';
$ln_requestmaterialType='Material Type';
$ln_requestPurpose='Withdraw Purpose';
$ln_requestquantity='Quantity';
$ln_requestsucess='You are successfully prepare request';


//prepare problem report
$ln_problemReportTopTitles=' Prepare Problem Report';
$ln_problemReportTitle='Title';
$ln_prepareProblemReportContent='Content';
$ln_prepareProblemReportContentplaceholder='Write your problem report ';
$ln_problemReportSuccess='you are successfully prepared problem report Thank you!!!';
//view feedback
$ln_viewFeedbackTopTitle='My Feedback';
$ln_viewFeedbackInnerTitle='Replayed Problem Report.';
$ln_viewFeedbackTo='TO :';
$ln_viewFeedbackTitle='Title: ';
$ln_viewFeedbackAnswered='Prepared by ';
$ln_viewFeedbackDelete='Click here to Delete :';
$ln_viewFeedbackPreparedon='Prepared on :';
$ln_viewFeedbackDayago=' days ago';
$ln_viewFeedbackYearago='  years ago';
$ln_viewFeedbackMonthago='  Months ago';
$ln_viewFeedbackMinuteago=' Minute ago';
$ln_viewFeedbackSecondago=' Second ago';
$ln_viewFeedbackbefore='';
$ln_viewFeedbackHourago=' Hour ago';
$ln_viewFeedbackDeleteSucess=' Succesfully Deleted your feedback.';
//generate report content


//left navigation 
$ln_propertyManger='F.A.Manager';
$ln_propertyMangerManageUsers='Manage Users';
$ln_propertyMangerViewproblemreport='View Problem Report';
$ln_propertyManagerApproveReport='Approve Report';
$ln_propertyMangerPrepareAnnouncement='Prepare Notification';
$ln_propertyMangerCreateAccount="Create User Account";
$ln_propertyMangerDeactivateUser='Deactivate Users';
$ln_propertyMangerDeactivateAssetUser='Deactivate Asset User';
$ln_propertyMangerDeactivateAssetManager='Deactivate Asset Manager';
$ln_propertyMangerActivateUser='Activate Users';
$ln_propertyMangerActivateAssetUser='Activate Asset User';
$ln_propertyMangerActivateAssetManager='Activate Asset Manager';
$ln_propertyMangerViewUser='View User Information';
$ln_propertyMangerViewAssetUser='View Asset User';
$ln_propertyMangerviewAssetManager='View Asset Manager';
$ln_propertyMangerViewAssetTitle='General Asset';
$ln_propertyMangerViewAssetExport='Export';
$ln_propertyManagerRequest='Request';
$ln_propertyMangerAssetUsers='Asset Users';
$ln_propertyMangerAsset='Assets';
$ln_propertyMangerNotification='Asset Item Less than 10 Quantity';
 $ln_createAccountSelect='Select User Type';
 $ln_createAccountTop='Create User Account';
//create user account
$ln_createAccountFirstName='First Name';
$ln_createAccountMiddleName='Middle Name';
$ln_createAccountConfirmEmail='Confirm Email';
$ln_createAccountConfirmPassword='Confirm Password';
$ln_createAccountUserType='User Type';
$ln_createAccountTelephone='Phone Number';
$ln_createAccountSex='Sex';
$ln_createAccountAdress='Address';
$ln_createAccountOccupation='Occupation';
$ln_createAccountSelectUser='Select User Type';

$ln_propertyMangerDeleteTooltip='Delete this Report';
$ln_propertyMangerReplayTooltip='Replay this Report';
$ln_propertyMangerViewproblemreportTitle='View Problem Title';
$ln_propertyMangerFeedback='Feedback';
$ln_propertyMangerunreplay='Unreplayed Problem report';
$ln_propertyMangerreplay='Replayed Problem Report';
$ln_propertyMangerDeleteReportsuccess='Succesfully Delete the Problem report';
$ln_propertyMangerViewUserFullname='Full Name';
$ln_propertyMangerViewUseroccupation='Occupation';
$ln_propertyMangerViewUserPhone='Phone Number';
$ln_propertyMangerViewUserAdress='Adress';
$ln_propertyMangerViewUserSex='Sex';
$ln_propertyMangerViewUserTitle='Genaral Asset User Information';
$ln_withdrawAppoitement='Appoitement Date';
$ln_withdrawAssetInfo='Info!';
$ln_withdrawAssetReturnMessage='In this Week You shoud Return';
$ln_withdrawAssetItem='Asset Item';
$ln_showMore='See More';

//lost asset
$ln_lostAssetNoAssetName=' Sorry You are not Withdraw such type of Asset ';
$ln_lostAssetNoAssetQuantity=' Sorry It is not Withdraw Such amount of ';
$ln_lostAssetAccountNumbernotFound=' Sorry The Account Number is not Correct';
$ln_lostAssetAccountPaswordnotFound =' Sorry The Account Password is not Correct';
$ln_lostAssetAccountNotEnoughmoney=' Sorry Currently You have not Enough Money In your Account';
$ln_lostAssetAccountPayed=' You are Sucessfully paid your lost Asset ';
$ln_download="Download";
$ln_assetUserName="Full Name";
$ln_appoitementDate="Appoitment Date";
$ln_serialNumber="Serial Number";
$ln_approveReturnedAssetTooltip="Approve returned asset";
$ln_returnAssetFrom= "Return Asset From";
$ln_approveReturnAssetnegative="Asset Quantity at least Greater than Zero";
$ln_approveReturnAssetMore="Please Minimize Asset Quantity";
$ln_approveReturnAssetSuccess="Successfully Returned the asset";
$ln_changePasswordCurrent="Please Enter Current Passwordssssssssss";
$ln_changePasswordNew="Please Enter New Password";
$ln_changePasswordConfirm="Please Enter Confirmation Password";
$ln_createAccountSuccess='You are Create Account SuccessFully';
$ln_createAccountFail='User Name Already Exist';


?>
